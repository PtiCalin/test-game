using TestGame.Core;
using UnityEngine;

namespace TestGame.Collectibles
{
    [RequireComponent(typeof(Collider))]
    public sealed class CoinBehaviour : MonoBehaviour
    {
        [Header("Value")]
        [SerializeField] private int value = 1;

        [Header("Animation")]
        [SerializeField] private float rotateSpeed = 120f;
        [SerializeField] private float bobAmplitude = 0.25f;
        [SerializeField] private float bobFrequency = 2f;

        [Header("Audio")]
        [SerializeField] private AudioClip pickupSfx;

        private Vector3 _startPos;

        private void Awake()
        {
            _startPos = transform.position;
            var c = GetComponent<Collider>();
            c.isTrigger = true;
        }

        private void Update()
        {
            transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime, Space.World);
            transform.position = _startPos + Vector3.up * (Mathf.Sin(Time.time * bobFrequency) * bobAmplitude);
        }

        private void OnTriggerEnter(Collider other)
        {
            if (!other.CompareTag("Player")) return;

            GameManager.Instance?.AddCollectible(value, isTreasure: false);
            PlaySfx();
            Destroy(gameObject);
        }

        private void PlaySfx()
        {
            if (pickupSfx == null) return;
            AudioSource.PlayClipAtPoint(pickupSfx, transform.position);
        }
    }
}
