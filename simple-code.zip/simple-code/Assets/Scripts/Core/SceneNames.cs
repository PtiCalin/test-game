namespace TestGame.Core
{
    public static class SceneNames
    {
        public const string Menu = "Menu";
        public const string Castle = "Castle";
        public const string YouLost = "YouLost";
        public const string YouWin = "YouWin";
    }
}
